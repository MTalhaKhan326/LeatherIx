import DashboardTemplate from "../../Components/Templates/DashboardTemplate.jsx";

function HelpScreen() {
  return (  
    <DashboardTemplate pageTitle={"Help"}>

    </DashboardTemplate>
  );
}

export default HelpScreen;