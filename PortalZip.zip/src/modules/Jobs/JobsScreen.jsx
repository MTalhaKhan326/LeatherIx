import DashboardTemplate from "../../Components/Templates/DashboardTemplate.jsx";

function JobsScreen() {
  return (  
    <DashboardTemplate pageTitle={"Jobs"}>

    </DashboardTemplate>
  );
}

export default JobsScreen;