import ListingTemplate from '../../ListingTemplate'

const Analysis = () => {
  return (
    <ListingTemplate>
      <div>Analysis</div>
    </ListingTemplate>
  );
}

export default Analysis