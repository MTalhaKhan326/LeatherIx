import DashboardTemplate from "../../Components/Templates/DashboardTemplate.jsx";

function MessagesScreen() {
  return (  
    <DashboardTemplate pageTitle={"Messages"}>

    </DashboardTemplate>
  );
}

export default MessagesScreen;