import DashboardTemplate from "../../Components/Templates/DashboardTemplate";

function CustomersScreen() {
  return (  
    <DashboardTemplate pageTitle={"Customers"}>

    </DashboardTemplate>
  );
}

export default CustomersScreen;