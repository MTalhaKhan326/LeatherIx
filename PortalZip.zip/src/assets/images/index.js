import eye from "./eye.svg";
import eyeCross from "./eye-cross.svg";
import onecall from "./onecall.png"
import img1 from "./img1.jpeg"
import img2 from "./img2.jpeg"
import barcode from "./barcode.jpg"
import postImage from "./postImage.jpg"

const AppImages = {
  eye,
  eyeCross,
  onecall,
  img1,
  img2,
  barcode,
  postImage
 
};
export default AppImages;
